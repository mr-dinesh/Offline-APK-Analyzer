#!/usr/bin/env python3
"""
APK Security Analyzer
A web-based tool for static analysis of Android APK files.
"""

import os, re, zipfile, hashlib, logging
from datetime import datetime
from flask import Flask, request, render_template, redirect, url_for, flash
from werkzeug.utils import secure_filename

logging.getLogger('androguard').setLevel(logging.CRITICAL)

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 150 * 1024 * 1024

ALLOWED_EXTENSIONS = {'apk'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_dex_classes(apk_path):
    try:
        from androguard.misc import AnalyzeAPK
        a, d, dx = AnalyzeAPK(apk_path)
        return set(c.name.lstrip('L').replace(';','').replace('.','/')
                   for c in dx.get_classes())
    except Exception as e:
        print(f"[DEX] {e}")
        return set()

def compute_hashes(apk_path):
    md5 = hashlib.md5()
    sha256 = hashlib.sha256()
    with open(apk_path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            md5.update(chunk); sha256.update(chunk)
    return md5.hexdigest(), sha256.hexdigest()

def parse_manifest(apk_path):
    result = {
        'package':'unknown','version_name':'unknown','version_code':'unknown',
        'min_sdk':'unknown','target_sdk':'unknown','debuggable':None,
        'allow_backup':None,'cleartext_traffic':None,'network_security_config':None,
        'permissions':[],'dangerous_permissions':[],'activities':[],'services':[],
        'receivers':[],'providers':[],'exported_components':[],'deep_link_schemes':[],
    }
    try:
        from androguard.core import apk as apk_mod
        a = apk_mod.APK(apk_path)
        result['package']      = a.get_package() or 'unknown'
        result['version_name'] = a.get_androidversion_name() or 'unknown'
        result['version_code'] = a.get_androidversion_code() or 'unknown'
        result['min_sdk']      = a.get_min_sdk_version() or 'unknown'
        result['target_sdk']   = a.get_target_sdk_version() or 'unknown'
        result['permissions']  = list(a.get_permissions() or [])
        result['activities']   = list(a.get_activities() or [])
        result['services']     = list(a.get_services() or [])
        result['receivers']    = list(a.get_receivers() or [])
        result['providers']    = list(a.get_providers() or [])
        for act in result['activities']:
            filters = a.get_intent_filters('activity', act)
            if filters:
                result['exported_components'].append(('Activity', act))
    except Exception:
        pass
    try:
        with zipfile.ZipFile(apk_path) as z:
            if 'AndroidManifest.xml' in z.namelist():
                text = z.read('AndroidManifest.xml').decode('utf-8', errors='ignore')
                pkg = re.search(r'package["\s=]+([a-zA-Z][a-zA-Z0-9._]+)', text)
                if pkg and result['package'] == 'unknown':
                    result['package'] = pkg.group(1)
                result['debuggable']              = 'true' if 'debuggable' in text.lower() and 'true' in text.lower() else 'false'
                result['allow_backup']            = 'false' if 'allowBackup' in text and 'false' in text[text.find('allowBackup'):text.find('allowBackup')+20] else 'true'
                result['cleartext_traffic']       = 'false' if 'usesCleartextTraffic' in text and 'false' in text else 'unknown'
                result['network_security_config'] = 'networkSecurityConfig' in text
                perms = re.findall(r'android\.permission\.[A-Z_]+', text)
                if perms and not result['permissions']:
                    result['permissions'] = list(set(perms))
    except Exception:
        pass
    DANGEROUS = {
        'ACCESS_FINE_LOCATION':'Precise GPS location',
        'ACCESS_COARSE_LOCATION':'Approximate location',
        'ACCESS_BACKGROUND_LOCATION':'⚠ Background location tracking',
        'CAMERA':'Camera access','RECORD_AUDIO':'Microphone access',
        'READ_CONTACTS':'Full contact list','READ_CALL_LOG':'Call history',
        'READ_SMS':'SMS messages — OTP interception risk',
        'PROCESS_OUTGOING_CALLS':'Intercept outgoing calls',
        'READ_PHONE_STATE':'Device ID / IMEI collection',
        'READ_EXTERNAL_STORAGE':'Read all files','WRITE_EXTERNAL_STORAGE':'Write files',
        'MANAGE_EXTERNAL_STORAGE':'⚠ Full storage access',
        'USE_BIOMETRIC':'Biometric hardware','USE_FINGERPRINT':'Fingerprint (deprecated)',
        'BIND_ACCESSIBILITY_SERVICE':'⚠ Screen reading / automation',
        'BODY_SENSORS':'Health sensors','GET_ACCOUNTS':'Account list enumeration',
    }
    CRITICAL_PERMS = {'ACCESS_BACKGROUND_LOCATION','BIND_ACCESSIBILITY_SERVICE',
                      'MANAGE_EXTERNAL_STORAGE','READ_SMS','PROCESS_OUTGOING_CALLS'}
    for perm in result['permissions']:
        short = perm.split('.')[-1]
        if short in DANGEROUS:
            result['dangerous_permissions'].append({
                'full':perm,'short':short,'description':DANGEROUS[short],
                'critical': short in CRITICAL_PERMS
            })
    return result

def scan_secrets(apk_path):
    findings = []
    PATTERNS = {
        'AWS Access Key':     (r'AKIA[0-9A-Z]{16}', 'CRITICAL'),
        'Private Key':        (r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----', 'CRITICAL'),
        'SendGrid Key':       (r'SG\.[A-Za-z0-9_\-]{22}\.[A-Za-z0-9_\-]{43}', 'CRITICAL'),
        'Hardcoded Password': (r'(?i)(?:password|passwd|pwd)\s*[=:]\s*["\']([^"\']{4,})["\']', 'HIGH'),
        'Bearer Token':       (r'(?i)bearer\s+[A-Za-z0-9\-._~+/]{20,}', 'HIGH'),
        'Staging URL':        (r'https?://[^\s"\'<>]*(?:staging|nonprod|dev\.|test\.)[^\s"\'<>]*', 'HIGH'),
        'Dynatrace Beacon':   (r'https?://[a-z0-9]+\.live\.dynatrace\.com', 'HIGH'),
        'Razorpay Key':       (r'rzp_(?:live|test)_[A-Za-z0-9]{14,}', 'HIGH'),
        'Firebase API Key':   (r'AIza[0-9A-Za-z\-_]{35}', 'MEDIUM'),
        'Internal IP':        (r'\b(?:10\.|192\.168\.|172\.(?:1[6-9]|2[0-9]|3[01])\.)\d{1,3}\.\d{1,3}\b', 'MEDIUM'),
        'Localhost URL':      (r'https?://(?:localhost|127\.0\.0\.1)[:/]', 'MEDIUM'),
        'Branch.io Key':      (r'key_live_[A-Za-z0-9]{20,}', 'MEDIUM'),
        'Crashlytics ID':     (r'[0-9]{1,3}:[0-9]{10,}:android:[a-f0-9]{16,}', 'LOW'),
    }
    try:
        with zipfile.ZipFile(apk_path) as z:
            scan_files = [f for f in z.namelist() if any(f.endswith(e) for e in
                ['.xml','.json','.js','.properties','.txt','.html','.yaml','.yml','.gradle'])]
            seen = set()
            for fname in scan_files:
                try:
                    content = z.read(fname).decode('utf-8', errors='ignore')
                    for pname, (pattern, severity) in PATTERNS.items():
                        for match in re.finditer(pattern, content):
                            val = match.group(0)[:80]
                            if (pname, val) not in seen:
                                seen.add((pname, val))
                                findings.append({'type':pname,'severity':severity,
                                    'value':val,'file':fname,
                                    'line':content[:match.start()].count('\n')+1})
                except Exception:
                    pass
            for f in z.namelist():
                if any(x in f.lower() for x in ['.p12','.jks','.bks','.pem','.key',
                       'keystore','truststore','secret','credential','private']):
                    findings.append({'type':'Sensitive File','severity':'HIGH',
                                     'value':f,'file':f,'line':0})
    except Exception as e:
        findings.append({'type':'Scan Error','severity':'INFO','value':str(e),'file':'','line':0})
    sev = {'CRITICAL':0,'HIGH':1,'MEDIUM':2,'LOW':3,'INFO':4}
    findings.sort(key=lambda x: sev.get(x['severity'],5))
    return findings

def fingerprint_sdks(apk_path):
    SDK_MAP = {
        'com/google/firebase/analytics':    ('Firebase Analytics',        'ANALYTICS',      'MEDIUM', 'Google — check Firestore rules'),
        'com/google/firebase/crashlytics':  ('Firebase Crashlytics',      'CRASH',          'LOW',    'Ensure PII not in crash reports'),
        'com/google/android/gms/ads':       ('Google AdMob',              'ADVERTISING',    'HIGH',   'Ad SDK — collects device and behavioral data'),
        'com/facebook/ads':                 ('Meta Audience Network',     'ADVERTISING',    'HIGH',   'Meta ad SDK — cross-app tracking'),
        'com/facebook':                     ('Facebook SDK',              'SOCIAL/AUTH',    'MEDIUM', 'Meta SDK — social login and sharing'),
        'com/clevertap/android':            ('CleverTap',                 'MARKETING',      'HIGH',   'Marketing automation — behavioral data to third party'),
        'com/moengage':                     ('MoEngage',                  'MARKETING',      'HIGH',   'Marketing automation — user profiling'),
        'com/mixpanel':                     ('Mixpanel',                  'ANALYTICS',      'MEDIUM', 'Product analytics'),
        'com/amplitude':                    ('Amplitude',                 'ANALYTICS',      'MEDIUM', 'Product analytics'),
        'com/appsflyer':                    ('AppsFlyer',                 'ATTRIBUTION',    'HIGH',   'Install attribution — cross-app tracking'),
        'io/branch/referral':               ('Branch.io',                 'ATTRIBUTION',    'MEDIUM', 'Deep link attribution — cross-app user tracking'),
        'com/onesignal':                    ('OneSignal',                 'PUSH/TRACKING',  'HIGH',   'Push + location tracking pipeline'),
        'com/adobe/marketing/mobile':       ('Adobe Experience Platform', 'TRACKING',       'HIGH',   'Full behavioral profiling — Analytics, Target, Identity, Audience'),
        'com/dynatrace':                    ('Dynatrace',                 'SESSION REPLAY', 'HIGH',   'Full session replay capable — verify DataCollectionLevel=PERFORMANCE'),
        'com/appdynamics':                  ('AppDynamics (Cisco)',        'APM',            'MEDIUM', 'App performance monitoring — data to Cisco'),
        'com/qualtrics':                    ('Qualtrics (SAP)',            'SURVEY',         'LOW',    'NPS/survey SDK'),
        'com/razorpay':                     ('Razorpay',                  'PAYMENTS',       'MEDIUM', 'Payment SDK — PCI scope'),
        'com/paytm':                        ('Paytm',                     'PAYMENTS',       'MEDIUM', 'Payment SDK'),
        'com/stripe/android':               ('Stripe',                    'PAYMENTS',       'MEDIUM', 'Payment SDK — PCI scope'),
        'com/datatheorem/android/trustkit': ('TrustKit',                  'CERT PINNING',   'GOOD',   'Certificate pinning — verify configuration'),
        'com/scottyab/rootbeer':            ('RootBeer',                  'ROOT DETECT',    'GOOD',   'Root detection — bypassable with Magisk'),
        'net/sqlcipher':                    ('SQLCipher',                 'DB ENCRYPT',     'GOOD',   'Encrypted SQLite'),
        'androidx/security/crypto':         ('EncryptedSharedPrefs',      'STORAGE CRYPT',  'GOOD',   'Encrypted SharedPreferences'),
        'androidx/biometric':               ('AndroidX Biometric',        'AUTH',           'GOOD',   'Hardware-backed biometric authentication'),
        'okhttp3':                          ('OkHttp',                    'HTTP CLIENT',    'LOW',    'Check CertificatePinner configuration'),
        'retrofit2':                        ('Retrofit',                  'HTTP CLIENT',    'LOW',    'REST client'),
        'org/bouncycastle':                 ('BouncyCastle',              'CRYPTO',         'MEDIUM', 'Verify version for CVEs'),
        'in/gov/uidai':                     ('UIDAI/Aadhaar',             'BIOMETRIC GOV',  'HIGH',   'Verify OTP hashing is not MD5'),
        'com/morpho':                       ('Morpho/IDEMIA',             'BIOMETRIC',      'MEDIUM', 'Biometric SDK'),
    }
    dex_classes = get_dex_classes(apk_path)
    found, unknown_ns = [], []
    try:
        with zipfile.ZipFile(apk_path) as z:
            all_paths = set(z.namelist()) | dex_classes
        for prefix, (name, category, risk, note) in SDK_MAP.items():
            if any(f.startswith(prefix) or f.startswith('smali/'+prefix) or
                   f.startswith('classes/'+prefix) for f in all_paths):
                found.append({'name':name,'category':category,'risk':risk,'note':note})
        KNOWN = ('android/','java/','javax/','kotlin/','kotlinx/','androidx/','dalvik/','sun/')
        ns = set()
        for c in dex_classes:
            parts = c.split('/')
            if len(parts) >= 3:
                ns.add('/'.join(parts[:3]))
        unknown_ns = sorted(n for n in ns if not any(n.startswith(k) for k in KNOWN))[:50]
    except Exception:
        pass
    found.sort(key=lambda x: {'HIGH':0,'MEDIUM':1,'LOW':2,'GOOD':3}.get(x['risk'],4))
    return found, unknown_ns

def analyze_crypto(apk_path):
    results = {'good': [], 'warnings': []}
    GOOD_SIGNALS = {
        'BiometricPrompt':                    'Modern biometric API (hardware-backed)',
        'AndroidKeyStoreProvider':            'AndroidKeyStore — hardware key storage',
        'KeyPermanentlyInvalidatedException': 'Biometric key invalidation on enrollment change',
        'GCMBlockCipher':                     'AES-GCM authenticated encryption',
        'CertificatePinner':                  'OkHttp certificate pinning',
        'TrustKit':                           'TrustKit pinning framework',
        'EncryptedSharedPreferences':         'Encrypted SharedPreferences',
        'SQLiteDatabase':                     'SQLCipher database encryption',
        'StrongBoxKeymaster':                 'StrongBox hardware security module',
    }
    WARN_SIGNALS = {
        'WebViewClient':            ('WebView present',               'Verify onReceivedSslError does not call handler.proceed()'),
        'AllowAllHostnameVerifier': ('⚠ TrustAll hostname verifier',  'Accepts any hostname — complete TLS bypass'),
        'TrustAllCerts':            ('⚠ TrustAll cert manager',       'Accepts any certificate — complete TLS bypass'),
        'NullHostnameVerifier':     ('⚠ Null hostname verifier',      'No hostname validation'),
        'ClipboardManager':         ('Clipboard access',              'Verify OTPs/passwords not persisted to clipboard'),
        'android/util/Log':         ('android.util.Log',              'Verify no PII/tokens in release build logs'),
        'timber/log/Timber':        ('Timber logger',                 'Verify release tree strips all debug logs'),
        'MessageDigest':            ('MessageDigest present',         'Verify MD5/SHA1 not used for security-critical operations'),
    }
    try:
        dex_classes = get_dex_classes(apk_path)
        with zipfile.ZipFile(apk_path) as z:
            zip_files = set(z.namelist())
        all_signals = dex_classes | zip_files
        for signal, desc in GOOD_SIGNALS.items():
            if any(signal in f for f in all_signals):
                results['good'].append({'signal': signal, 'description': desc})
        for signal, (title, detail) in WARN_SIGNALS.items():
            if any(signal in f for f in all_signals):
                results['warnings'].append({'signal': signal, 'title': title, 'detail': detail})
    except Exception as e:
        print(f"[CRYPTO] {e}")
    return results

def analyze_nsc(apk_path):
    result = {'found':False,'cleartext_permitted':None,'user_certs_trusted':False,
              'has_pinning':False,'pin_expiration':None,'pin_expired':False,
              'unpinned_domains':[],'raw':'','findings':[]}
    try:
        with zipfile.ZipFile(apk_path) as z:
            nsc = [f for f in z.namelist() if 'network_security' in f.lower() and f.endswith('.xml')]
            if not nsc:
                result['findings'].append({'status':'WARN','text':'No network_security_config.xml found',
                    'detail':'App relies on platform defaults. User CA certs may be trusted on older Android versions.'})
                return result
            result['found'] = True
            xml = z.read(nsc[0]).decode('utf-8', errors='ignore')
            result['raw'] = xml
            if 'cleartextTrafficPermitted="false"' in xml:
                result['cleartext_permitted'] = False
                result['findings'].append({'status':'PASS','text':'Cleartext traffic disabled','detail':'No HTTP plaintext permitted at OS level'})
            elif 'cleartextTrafficPermitted="true"' in xml:
                result['cleartext_permitted'] = True
                result['findings'].append({'status':'FAIL','text':'Cleartext traffic PERMITTED','detail':'HTTP connections allowed — data transmitted unencrypted'})
            if 'src="user"' in xml:
                result['user_certs_trusted'] = True
                result['findings'].append({'status':'FAIL','text':'User CA certificates trusted','detail':'Trivial MITM with Burp/Charles proxy'})
            else:
                result['findings'].append({'status':'PASS','text':'User CA certificates not trusted','detail':'Cannot MITM without root or pinning bypass'})
            if '<pin-set' in xml:
                result['has_pinning'] = True
                result['findings'].append({'status':'PASS','text':'Certificate pinning configured','detail':'pin-set present in network security config'})
                exp = re.search(r'expiration="([^"]+)"', xml)
                if exp:
                    exp_date = exp.group(1)
                    result['pin_expiration'] = exp_date
                    try:
                        if datetime.strptime(exp_date, '%Y-%m-%d') < datetime.now():
                            result['pin_expired'] = True
                            result['findings'].append({'status':'FAIL','text':f'Pin expiration LAPSED: {exp_date}',
                                'detail':'Android silently disables pinning when expiration passes'})
                        else:
                            result['findings'].append({'status':'PASS','text':f'Pin expiration valid: {exp_date}','detail':'Pinning is active'})
                    except ValueError:
                        pass
            else:
                result['findings'].append({'status':'WARN','text':'No certificate pinning','detail':'Any valid CA-issued cert accepted'})
    except Exception as e:
        result['findings'].append({'status':'ERROR','text':f'Parse error: {e}','detail':''})
    return result

def score_risk(manifest, secrets, sdks, crypto, nsc):
    critical, high, medium, low = [], [], [], []
    for f in nsc.get('findings',[]):
        if f['status'] == 'FAIL':
            (critical if 'expiration' in f['text'].lower() or 'pinning' in f['text'].lower() else high).append(f['text'])
    for s in secrets:
        if s['severity'] == 'CRITICAL': critical.append(f"{s['type']}: {s['value'][:40]}")
        elif s['severity'] == 'HIGH':   high.append(f"{s['type']} in {s['file']}")
        elif s['severity'] == 'MEDIUM': medium.append(s['type'])
    for sdk in sdks:
        if sdk['risk'] == 'HIGH':   high.append(f"{sdk['name']} [{sdk['category']}]")
        elif sdk['risk'] == 'MEDIUM': medium.append(f"{sdk['name']} SDK")
    for p in manifest.get('dangerous_permissions',[]):
        (high if p.get('critical') else medium).append(f"Permission: {p['short']}")
    for w in crypto.get('warnings',[]):
        (critical if '⚠' in w['title'] else medium).append(w['title'])
    score = max(0, min(100, 100 - len(critical)*20 - len(high)*10 - len(medium)*3))
    grade = 'A' if not critical and not high else \
            'B' if score >= 80 else 'C' if score >= 60 else 'D' if score >= 40 else 'F'
    color = 'green' if grade in ('A','B') else 'orange' if grade == 'C' else 'red'
    return {'score':score,'grade':grade,'color':color,
            'critical':critical,'high':high,'medium':medium,'low':low}

def run_analysis(apk_path):
    md5, sha256 = compute_hashes(apk_path)
    manifest = parse_manifest(apk_path)
    secrets  = scan_secrets(apk_path)
    sdks, ns = fingerprint_sdks(apk_path)
    crypto   = analyze_crypto(apk_path)
    nsc      = analyze_nsc(apk_path)
    risk     = score_risk(manifest, secrets, sdks, crypto, nsc)
    return {
        'meta': {'filename': os.path.basename(apk_path),
                 'file_size': f"{os.path.getsize(apk_path)/1024/1024:.1f} MB",
                 'md5': md5, 'sha256': sha256,
                 'analyzed_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')},
        'manifest': manifest, 'secrets': secrets, 'sdks': sdks,
        'namespaces': ns, 'crypto': crypto, 'nsc': nsc, 'risk': risk,
    }

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'apk_file' not in request.files:
        flash('No file selected'); return redirect(url_for('index'))
    file = request.files['apk_file']
    if not file or file.filename == '':
        flash('No file selected'); return redirect(url_for('index'))
    if not allowed_file(file.filename):
        flash('Only .apk files are supported'); return redirect(url_for('index'))
    apk_path = os.path.join(app.config['UPLOAD_FOLDER'], secure_filename(file.filename))
    file.save(apk_path)
    try:
        results = run_analysis(apk_path)
    except Exception as e:
        flash(f'Analysis failed: {str(e)}'); return redirect(url_for('index'))
    finally:
        if os.path.exists(apk_path): os.remove(apk_path)
    return render_template('report.html', r=results)

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=False, host='0.0.0.0', port=5000)
